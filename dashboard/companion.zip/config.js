﻿window.COMPANION_SUPABASE_CONFIG = {"url":"https://xiqteymwbnqmtsueubhu.supabase.co","publishableKey":"sb_publishable_oCMaBtv9aX7iahPfK0bPUA_nLq3dlQx"};
